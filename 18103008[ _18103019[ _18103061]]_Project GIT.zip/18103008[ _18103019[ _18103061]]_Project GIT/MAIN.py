
from flask import Flask, render_template, request, redirect
import mysql.connector as con
import os
import os.path
import time
from datetime import datetime


path = r"C:\Users\nishp_000\Desktop\PEC\SECOND YEAR\Python\PROJECT\checker"
files = []
# r=root, d=directories, f = files
for r, d, f in os.walk(path):
    for file in f:
        files.append(os.path.join(r, file))

filedb = con.connect(host="localhost", user="root",
                     passwd="abcd1", port="3306", database="bazinga")
                     
cur = filedb.cursor()
#cur.execute("CREATE TABLE mineee (firstName VARCHAR(255),lastName VARCHAR(255))")

app = Flask(__name__)

arr=[]

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == "POST":
        details = request.form
        arr.append(details['uid'])
        arr.append(details['email'])
        #firstName = details['fname']
        #lastName = details['lname']
        #cur.execute("INSERT INTO mineee(firstName, lastName) VALUES (%s, %s)", (firstName, lastName))
        cur.execute("INSERT INTO users (uid,FirstName,LastName,EMail,Password) VALUES (%s,%s,%s,%s,%s)",
                    (details['uid'], details['fname'], details['lname'], details['email'], details['password']))
        filedb.commit()
        return redirect('/work')        
    return render_template("page.html")


@app.route('/work', methods=['GET', 'POST'])
def worker():
    return render_template("WorkPage.html")

@app.route('/uploader', methods=['GET', 'POST'])
def upload():
    if request.method == "POST":
        f = request.files['fileee']
        cur.execute("INSERT INTO projects (uid,PROJECTFile,CreationDate) VALUES(%s,%s,%s)",
                    (arr[0], f.filename, time.strftime('%A %B, %d %Y %H:%M:%S')))
        filedb.commit()
        return redirect('/Projects')
    return 'done'


@app.route('/Projects', methods=['GET', 'POST'])
def projss():
    cur.execute("SELECT * FROM projects")
    user_details = {}
    for a, b, c, d in cur.fetchall():
        user_details = {'id': a, 'vno': b, 'proj': c, 'date': d,'name':arr[1]}
    if request.method=="POST":
        return redirect("/work")
    return render_template("TABLEPAGE.html", user=user_details)


if __name__ == '__main__':
    app.run()